package com.simpli;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/list")
public class ProductListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		// STEP 2:
		InputStream in = getServletContext().getResourceAsStream("/WEB-INF/config.properties");
		Properties props = new Properties();
		props.load(in);

		String url = props.getProperty("url");
		String userid = props.getProperty("userid");
		String password = props.getProperty("password");

		DBConnection dbConnection = null;

		try {

			dbConnection = new DBConnection(url, userid, password);
			Connection connection = dbConnection.getConnection();
			
		
			// STEP 3: Create the Statement Object
			Statement stmt =  connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,	ResultSet.CONCUR_READ_ONLY);
			
			// STEP 4: Get the Results in ResultSet object
			ResultSet rs = stmt.executeQuery("select * from product");
			
			out.println("product LIST<br><br>");
			out.println("<table border=1><th>ID<th>NAME<th>PRICE<th>DATE ADDED</th>");
			
			while(rs.next()) {
				
				String ID = rs.getString("ID");
				String name = rs.getString("name");
				float price = rs.getFloat("price");
				String dateAdded = rs.getString("date_added");
				
				//out.println(ID+ " ,"+ name+ " ,"+ price+ " ,"+ dateAdded + "<br>");	
				
				out.println("<tr><td>"+ ID+ "<td>"+ name+ "<td>"+ price+ "<td>"+ dateAdded + "</tr>");
				
			}
			out.println("</table>");
			

		} catch (Exception e) {
			out.println(e);
		}
	}
		
		
}