package com.simpli;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/callsp")
public class CallStoredProcedureServlet extends HttpServlet {
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		// STEP 2:
		InputStream in = getServletContext().getResourceAsStream("/WEB-INF/config.properties");
		Properties props = new Properties();
		props.load(in);

		String url = props.getProperty("url");
		String userid = props.getProperty("userid");
		String password = props.getProperty("password");

		DBConnection dbConnection = null;

		try {

			dbConnection = new DBConnection(url, userid, password);
			Connection connection = dbConnection.getConnection();
			
		
			// STEP 3: Create the callable Statement.class
			CallableStatement callableStmt = connection.prepareCall("{call add_product(?,?)}");
			callableStmt.setString(1, "Apple iPad" );
			callableStmt.setFloat(2, 100000);
			callableStmt.execute();
			
			out.println("Succesfully called the SP add_product. You can verify Product List link in");
			
		}catch (Exception e) {
			out.println(e);
	}


	}

}
