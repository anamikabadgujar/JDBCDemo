package com.simpli;

public @interface WebServlet {

	String value();

}
