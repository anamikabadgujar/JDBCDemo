package com.simpli;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/initjdbc")
public class InitJDBC extends HttpServlet {
	
     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		
		//STEP2:
		InputStream in = getServletContext().getResourceAsStream("/WEB-INF/config.properties" );
		Properties props = new Properties();
		props.load(in);
		
		String url = props.getProperty("url");
		String userid = props.getProperty("userid");
		String password = props.getProperty("password");
		
		DBConnection dbConnection = null;
		
		try {
			
			dbConnection = new DBConnection(url, userid, password);
			
			out.println("JDBC initialised SUCCESS");
			
		} catch (Exception e) {
			out.println("JDBC initialization FAILED!");
		}
	}

	
	
}


